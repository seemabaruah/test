package com.wipro.mymoney;

import au.com.anthonybruno.Gen;
import au.com.anthonybruno.generator.defaults.IntGenerator;
import au.com.anthonybruno.generator.defaults.StringGenerator;
import com.github.javafaker.Faker;

import java.io.File;
import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Locale;
import java.util.concurrent.TimeUnit;


public class TestData {
    private static final DateFormat DATE_FORMAT = new SimpleDateFormat("dd-MM-yyyy");

    public void generate(String fileName, int numItems, String email, String addressType) {

        Faker faker = new Faker(new Locale("en-GB"));
        NiNumberGenerator niNumberGenerator = new NiNumberGenerator();
        CountryName coutryName = new CountryName();

        String testDataDirectoryPath = System.getProperty("user.home") + "/idr-test-data";
        File testDataDirectory = new File(testDataDirectoryPath);
        if (!testDataDirectory.exists()) {
            testDataDirectory.mkdirs();
        }

        String testDataFilePath = testDataDirectoryPath + "/" + fileName;
        File testDataFile = new File(testDataFilePath);
        if (testDataFile.exists()) {
            testDataFile.delete();
        }
        try {
            testDataFile.createNewFile();
        } catch (IOException e) {
            System.out.println("Got exception: " + e);
        }

        System.out.println("Creating test file at path: " + testDataFilePath);
        DataUtils dataUtils = new DataUtils();
        Gen.start()
                .addField("Title", () -> faker.name().prefix())
                .addField("First Name", () -> faker.name().firstName())
                .addField("Surname", () -> faker.name().lastName())
                .addField("NI Number", niNumberGenerator::generate)
                .addField("Gender", context -> dataUtils.mapTitleToGender(
                        context.getFieldValue("Title", String.class)))
                .addField("Date Of Birth",() -> DATE_FORMAT.format(faker.date().birthday(30, 68)))
                .addField("Address Line 1",() -> faker.address().buildingNumber())
                .addField("Address Line 2", () -> faker.address().streetName())
                .addField("Address Line 3",() ->faker.address().cityName())
                .addField("Address Line 4",()->coutryName.adLineFour(addressType))
                .addField("Address Line 5",()->coutryName.addressType(addressType))
                .addField("Postcode",()-> faker.address().zipCode())
                .addField("Country", ()->coutryName.countryName(addressType))
                .addField("Salary", new IntGenerator(25000,40000))
                .addField("Evening Telephone Number",()->faker.phoneNumber().cellPhone())
                .addField("Daytime telephone number", ()->faker.phoneNumber().phoneNumber())
                .addField("Email Address (Work)", ()->email)
                .addField("Email Address (Personal)",()->email)
                .addField("Email Preference", () ->"Work")
                .addField("Preferred contact method",()->"Phone")
                .addField("Employer reference", new StringGenerator())
                .addField("SalarySacrifice", ()->"N")
                .addField("Marketing Opt Out",()->"N")
                .addField("Tax rate (Basic/Higher)",()->"Basic")
                .addField("Contribution Frequency",() -> "Monthly")
                .addField("Employer Contribution Percentage", new IntGenerator(2,5))
                .addField("Employee Contribution Percentage", new IntGenerator(1,5))
                .addField("Additional Voluntary Contribution Percentage",() -> "")
                .addField("Additional Voluntary Contribution Amount",()->"")
                .addField("Employer Additional Cont Percent", ()->"")
                .addField("Employer Additional Cont Amount",()->"")
                .addField("Employee AVC Percent", ()->"")
                .addField("Employee AVC Amount", ()->"")
                .addField("Employee Category", ()->"EmpCatsch")
                .addField("Date Joined Employer",()->DATE_FORMAT.format(faker.date().past(30, TimeUnit.DAYS)))
                .addField("Enrol in Pension Y/N", ()->"Y")
                .addField("Contribution Start Date",()->DATE_FORMAT.format((faker.date().future(20,2,TimeUnit.DAYS))))
                .addField("Selected Retirement Age", new IntGenerator(60, 65))
                .addField("Active Member Date", ()->DATE_FORMAT.format((faker.date().past(30,TimeUnit.DAYS))))
                .addField("Contractual Joiner",()->"N")
                .addField("Left Employment Indicator",()->"")
                .addField("Date Left Employment",()->"")
                .addField("Ceased Active membership",()->"N")
                .addField("Ceased Active membership effective date",()->"")
                .addField("Date Joined Employers Scheme",()->DATE_FORMAT.format(faker.date().past(30,TimeUnit.DAYS)))
                .addField("Salary Sacrifice Contributions",()->"N")
                .addField("Salary Sacrifice AVC",()->"N")
                .addField("Member Category",()->"")
                .addField("Silent Re-Joiner",()->"")


                .generate(numItems)
                .asCsv()
                .toFile(testDataFile);
    }
}
