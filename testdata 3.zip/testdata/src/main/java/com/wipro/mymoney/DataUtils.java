package com.wipro.mymoney;

public class DataUtils {

    public String mapTitleToGender(String Title) {
        if ("Mr".equalsIgnoreCase(Title) || "Dr".equalsIgnoreCase(Title)) {
            return "Male";
        }
        return "Female";
    }

}
