package com.wipro.mymoney;

import java.util.Arrays;
import java.util.List;

public class Main {


    public static void main(String args[]) {
        String fileName = args[0];
        int numItems = Integer.parseInt(args[1]);
        String email = args[2];

        System.out.println("FileName entered: " + fileName);
        System.out.println("Num items entered: " + numItems);
        TestData testData = new TestData();
        testData.generate(fileName, numItems,email);

    }

}
