package com.wipro.mymoney;

import java.util.Arrays;
import java.util.List;
import java.util.Random;

public class CountryName {

    public String countryName() {

        List<String> COUNTRYGB = Arrays.asList("UK","England","Wales","Scotland","Northern Ireland" );
        Random run = new Random();
        int random = run.nextInt(COUNTRYGB.size());
        String cname = COUNTRYGB.get(random);
        return cname;
    }


}
