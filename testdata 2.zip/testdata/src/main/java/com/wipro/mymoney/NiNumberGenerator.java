package com.wipro.mymoney;

import au.com.anthonybruno.generator.Generator;

import java.util.Arrays;
import java.util.List;
import java.util.Random;

public class NiNumberGenerator implements Generator<String> {

    private static List<Character> FIRST_ALLOWED = Arrays.asList('A', 'B', 'C', 'E', 'G', 'H', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'R',
            'S', 'T', 'W', 'X', 'Y', 'Z');
    private static List<Character> SECOND_ALLOWED = Arrays.asList('A', 'B', 'C', 'E', 'G', 'H', 'J', 'K', 'L', 'M', 'N', 'P', 'R',
            'S', 'T', 'W', 'X', 'Y', 'Z');
    private static List<Character> LAST_ALLOWED = Arrays.asList('A', 'B', 'C', 'D');
    private static List<String> NOT_ALLOWED = Arrays.asList("GB", "BG", "NK", "KN", "TN", "NT", "ZZ");

    public String generate () {
        return   generatePrefix()+generateSixDigitRandomNumber()+generateSuffix();
    }

    private String generatePrefix() {
        Random ran = new Random();
        int random = ran.nextInt(FIRST_ALLOWED.size());
        int random2 = ran.nextInt(SECOND_ALLOWED.size());


        Character firstCharacter = FIRST_ALLOWED.get(random);
        Character secondCharacter = SECOND_ALLOWED.get(random2);

        String prefix = firstCharacter.toString() + secondCharacter.toString();

        while (NOT_ALLOWED.contains(prefix)) {
            random = ran.nextInt(FIRST_ALLOWED.size());
            random2 = ran.nextInt(SECOND_ALLOWED.size());


            firstCharacter = FIRST_ALLOWED.get(random);
            secondCharacter = SECOND_ALLOWED.get(random2);

            prefix = firstCharacter.toString() + secondCharacter.toString();
        }
        return prefix;

    }
    private String generateSixDigitRandomNumber(){
        Random number = new Random();
        int digit = number.nextInt(999999);
        return String.format("%06d", digit);

    }

    private String generateSuffix(){
        Random ran = new Random();
        int random =ran.nextInt(LAST_ALLOWED.size());
        Character lastLetter = LAST_ALLOWED.get(random);
        return lastLetter.toString();
    }
}
