package com.wipro.mymoney;

public class DataUtils {

    public String mapTitleToGender(String title) {
        if ("Mr.".equalsIgnoreCase(title) || "Dr.".equalsIgnoreCase(title)) {
            return "Male";
        }
        return "Female";
    }

}
