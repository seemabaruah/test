package com.wipro.mymoney;

import au.com.anthonybruno.generator.Generator;
import com.github.javafaker.Faker;

import java.util.Arrays;
import java.util.List;
import java.util.Locale;
import java.util.Random;

public class CountryName  {

    Faker faker = new Faker(new Locale("en-GB"));

    public String addressType (String addressType) {
        if ("UK".equalsIgnoreCase(addressType))
        {
            return "";
        }
        else {

            return faker.address().cityName();
        }

    }

    public String countryName(String addressType) {
        if ("UK".equalsIgnoreCase(addressType)){
            return "UK";
        }
    else{
            List<String> COUNTRYGB = Arrays.asList("Austria","Andorra","Argentina","Algeria","Antiqua","Armenia","Aruba","Australia","Austria","Azerbaijan","Bahamas","Bahrain","Bangladesh","Barbados","Belarus","Belgium","Bermuda","Bolivia","Botswana","Brazil","British Virgin Islands","Brunei","Bulgaria","Cabo Verde","Canada”,”Cayman Islands","Chile","China","Colombia","Cook Islands","Costa","Rica","Croatia","Cyprus","Czech","Denmark","Ecuador","Egypt","El Salvador","Estonia","Fiji","Finland","France",
                    "French Polynesia","Gambia","Germany","Ghana" ,"Gibraltar","Greece","Guernsey","Hong Kong","Hungary","Iceland","India","Indonesia","Iran","Ireland","Isle of Man","Israel","Italy","Jamaica","Japan","Jersey","Jordan","Kazakhstan","Kenya","Korea","Kuwait","Latvia","Lebanon","Lithuania","Luxembourg","Macedonia","Malaysia","Malta","Mauritania","Mauritius","Mexico","Monaco","Montserrat","Morocco","Netherlands","Netherlandsn Antilles","New Zealand","Nigeria","Norway","Oman","Pakistan",

                    "Papua New Guinea","Peru","Philippines","Poland","Portugal","Qatar","Romania","Russia","Saudi","Arabia","Serbia","Sierra","Leone","Singapore",

                    "Slovakia","Slovenia","South","Africa","South","Korea","Spain","Sri Lanka","Swaziland","Sweden","Switzerland","Taiwan","Tanzania","Thailand","Tonga",

                    "Trinidad and Tobago","Tunisia","Turkey","Turks and Caicos Islands","Uganda","UK","Ukraine","United Arab Emirates","Uruguay","USA",

                    "Vanuatu","Venezuela","Vietnam","West","Indies","Western Samoa","Zambia","Zimbabwe");

            Random run = new Random();
            int random = run.nextInt(COUNTRYGB.size());
            return COUNTRYGB.get(random);
        }
    }

    public String adLineFour(String addressType){

        if("UK".equalsIgnoreCase(addressType))
        {
            List<String> ADDRESSLINE4 = Arrays.asList("England","Wales","Scotland","Northern Ireland" );
            Random run = new Random();
            int random = run.nextInt(ADDRESSLINE4.size());
            return ADDRESSLINE4.get(random);
        }
        else
        {
            return faker.address().state();
        }


    }




}

