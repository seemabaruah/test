package com.wipro.mymoney;

import au.com.anthonybruno.Gen;
import au.com.anthonybruno.generator.defaults.IntGenerator;
import com.github.javafaker.Faker;

import java.text.DateFormat;
import java.text.SimpleDateFormat;


public class TestData {
    private static final DateFormat DATE_FORMAT = new SimpleDateFormat("dd-MM-yyyy");

    public void generate() {
        Faker faker = Faker.instance();
        NiNumberGenerator niNumberGenerator = new NiNumberGenerator();

        Gen.start()
                .addField("First Name", () -> faker.name().firstName())
                .addField("Last Name", () -> faker.name().lastName())
                .addField("RetirementAge", new IntGenerator(58, 70))
                .addField("NI Number", niNumberGenerator::generate)
                .addField("DOB",() -> DATE_FORMAT.format(faker.date().birthday(30, 74)))
                .addField("title", () -> faker.name().prefix())
                .addField("gender", context -> context.getFieldValue("title", String.class))
                .generate(100)
                .asCsv()
                .toFile("new.csv");
    }
}
