package com.wipro.mymoney;

import java.util.Arrays;
import java.util.List;

public class Main {


    public static void main(String args[]) {

            TestData testData = new TestData();
            testData.generate();

    }

}
